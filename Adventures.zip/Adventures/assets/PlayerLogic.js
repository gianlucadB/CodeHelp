import EventListener from "./EventListener.js";
import {playerTimmy} from "./index.js";
import {background} from "./index.js";
import {boundaries} from "./index.js";

const event = new EventListener();

function rectangularCollision({rectangle1, rectangle2}) {
    return (
        rectangle1.position.x + rectangle1.width >= rectangle2.position.x &&
        rectangle1.position.x <= rectangle2.position.x + rectangle2.width &&
        rectangle1.position.y <= rectangle2.position.y + rectangle2.height &&
        rectangle1.position.y + rectangle1.height >= rectangle2.position.y
    )
}

export default function playerLogic() {
    const movables = [background];

    let moving = true
    playerTimmy.moving = false

    if (event.keys.w.pressed) {
        playerTimmy.moving = true
        playerTimmy.image = playerTimmy.sprites.up

        for (let i = 0; i < boundaries.length; i++) {
            const boundary = boundaries[i]
            if (rectangularCollision({
                rectangle1: playerTimmy,
                rectangle2: {
                    ...boundary, position: {
                        x: boundary.position.x,
                        y: boundary.position.y + 1
                    }
                }
            })
            ) {
                moving = false
                break
            }
        }

        if (moving)
            movables.forEach(movable => {
                movable.position.y += 1
            })
    } else if (event.keys.a.pressed) {
        playerTimmy.moving = true
        playerTimmy.image = playerTimmy.sprites.left

        for (let i = 0; i < boundaries.length; i++) {
            const boundary = boundaries[i]
            if (rectangularCollision({
                rectangle1: playerTimmy,
                rectangle2: {
                    ...boundary, position: {
                        x: boundary.position.x + 1,
                        y: boundary.position.y
                    }
                }
            })
            ) {
                moving = false
                break
            }
        }

        if (moving)
            movables.forEach(movable => {
                movable.position.x += 1
            })
    } else if (event.keys.s.pressed) {
        playerTimmy.moving = true
        playerTimmy.image = playerTimmy.sprites.down

        for (let i = 0; i < boundaries.length; i++) {
            const boundary = boundaries[i]
            if (rectangularCollision({
                rectangle1: playerTimmy,
                rectangle2: {
                    ...boundary, position: {
                        x: boundary.position.x,
                        y: boundary.position.y - 1
                    }
                }
            })
            ) {
                moving = false
                break
            }
        }

        if (moving)
            movables.forEach(movable => {
                movable.position.y -= 1
            })
    } else if (event.keys.d.pressed) {
        playerTimmy.moving = true
        playerTimmy.image = playerTimmy.sprites.right

        for (let i = 0; i < boundaries.length; i++) {
            const boundary = boundaries[i]
            if (rectangularCollision({
                rectangle1: playerTimmy,
                rectangle2: {
                    ...boundary, position: {
                        x: boundary.position.x - 1,
                        y: boundary.position.y
                    }
                }
            })
            ) {
                moving = false
                break
            }
        }

        if (moving)
            movables.forEach(movable => {
                movable.position.x -= 1
            })
    }
}