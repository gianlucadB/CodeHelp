export default class EventListener {
    constructor() {
        this.keys = {
            w: { pressed: false },
            a: { pressed: false },
            s: { pressed: false },
            d: { pressed: false },
            x: { pressed: false },
            c: { pressed: false },
            v: { pressed: false },
            enter: { pressed: false },
            left: { pressed: false },
        };
        window.addEventListener("keydown", this.keyDown.bind(this));
        window.addEventListener("keyup", this.keyUp.bind(this));
        window.addEventListener("mousedown", this.mouseDown.bind(this));
        window.addEventListener("mouseup", this.mouseUp.bind(this));
    }

    keyDown(event) {
        const key = event.key.toLowerCase();
        if (key in this.keys) {
            this.keys[key].pressed = true;
        }
    }

    keyUp(event) {
        const key = event.key.toLowerCase();
        if (key in this.keys) {
            this.keys[key].pressed = false;
        }
    }

    mouseDown(event) {
        if (event.button === 0) {
            this.keys["left"].pressed = true;
        }
    }

    mouseUp(event) {
        if (event.button === 0) {
            this.keys["left"].pressed = false;
        }
    }
}