import img from "./img.js";
import Raindrops from "./Raindrops.js";
import Sprite from "./Sprite.js";
import playerLogic from "./PlayerLogic.js";
import Boundary from "./Boundary.js";
import {collisions} from "./collisions.js";

const canvas = document.getElementById('canvas');
const c = canvas.getContext('2d');

canvas.width = innerWidth;
canvas.height = innerHeight;

const offset = {
    x: canvas.width / 2 - 200,
    y: canvas.height / 2 - 100
}

const collisionsMap = [];

for (let i = 0; i < collisions.length; i += 70) {
    collisionsMap.push(collisions.slice(i, 70 + i));
}

export const boundaries = [];

collisionsMap.forEach((row, i) => {
    row.forEach((symbol, j) => {
        if (symbol === 790)
            boundaries.push(
                new Boundary({
                    c: c,
                    position: {
                        x: j * Boundary.width + offset.x,
                        y: i * Boundary.height + offset.y
                    }
                })
            )
    })
});

const raindrops = [];

for (let i = 0; i < 1000; i++) {
    const x = Math.random() * canvas.width;
    const y = Math.random() * canvas.height;
    const radius = 1;
    raindrops.push(new Raindrops(c, canvas, x, y, radius));
}

const backgroundImage = img("BackgroundFloor.png");

const timmyUp = img("TimmyUp.png");
const timmyDown = img("TimmyDown.png");
const timmyRight = img("TimmyRight.png");
const timmyLeft = img("TimmyLeft.png");

export const playerTimmy = new Sprite({
    c: c,
    position: {
        x: canvas.width / 2 - 16,
        y: canvas.height / 2 - 8
    },
    image: timmyDown,
    frames: {
        max: 4
    },
    sprites: {
        up: timmyUp,
        down: timmyDown,
        right: timmyRight,
        left: timmyLeft
    }
});

export const background = new Sprite({
    c: c,
    position: {
        x: offset.x,
        y: offset.y
    },
    image: backgroundImage
});

function animate() {
    window.requestAnimationFrame(animate);
    c.clearRect(0, 0, canvas.width, canvas.height);

    playerLogic();

    background.update();

    raindrops.forEach(raindrop => {
        raindrop.draw();
        raindrop.update();
    });

    boundaries.forEach(boundary => {
        boundary.draw();
    });

    playerTimmy.update();
}

animate();