export default function img(src) {
    const image = new Image();
    image.src = "../images/" + src;
    return image;
}