export default class Raindrops {
    constructor(c, canvas, x, y, radius) {
        this.c = c;
        this.canvas = canvas;
        this.x = x;
        this.y = y;
        this.radius = radius;
        this.speed = Math.random() * 3 + 1;
    }

    draw() {
        this.c.beginPath();
        this.c.moveTo(this.x, this.y);
        this.c.lineTo(this.x, this.y + this.radius * 2);
        this.c.strokeStyle = "rgba(0,150,255,0.5)";
        this.c.lineWidth = 2;
        this.c.stroke();
    }

    update() {
        this.y += this.speed;
        if (this.y > this.canvas.height) {
            this.y = -this.radius;
        }
    }
}